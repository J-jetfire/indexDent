<!--   пространства   -->
<div class="row profile_footer">
      <div class="row footer__back" style="margin:20px auto;height:50px;width:100%;padding-top:15px;">
         <h5><a id="private_policy">«Политика конфиденциальности»</a> | <a id="terms_of_use">«Правила использования»</a></h5>
      </div>
   </div>
<!--   пространства   -->

<!-- MODAL TERMS -->
<div class="modal fade" id="modal_terms" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="this_container" id="modal_this_container">
            <h5>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Totam cum voluptatem deleniti corporis fugit, quo commodi tempora aut ipsum nihil sapiente, quod fugiat perferendis quaerat assumenda a sunt inventore saepe.</h5>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Modal TERMS -->
<!-- MODAL POLICY -->
<div class="modal fade" id="modal_policy" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="this_container" id="modal_this_container">
            <h5>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Totam cum voluptatem deleniti corporis fugit, quo commodi tempora aut ipsum nihil sapiente, quod fugiat perferendis quaerat assumenda a sunt inventore saepe.</h5>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Modal POLICY -->
