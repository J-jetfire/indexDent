    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

<!--    <meta name="viewport" content="width=device-width, minimum-width=1280px, maximum-scale=2, initial-scale=1">-->
    <meta name="viewport" content="width=1920px, maximum-scale=1.0, minimum-scale=0.1">

    <!-- BOOTSTRAP STYLES -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css">

    <!-- CSS STYLES -->
    <link rel="stylesheet" href="fonts/century/stylesheet.css">

    <!-- jQuery.js -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
