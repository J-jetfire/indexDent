<!--   header stable  -->
   <header class="header">
      <div class="row header__back" style="">
         <div class="col-xs-2"><img src="img/logo.png" alt="" id="logotype"></div>
         <div class="col-xs-7">
            <div class="row search_row">
               <button id="search"><img src="img/icons/search_icon_1.png" alt="" id="img1">Поиск<img src="img/icons/search_icon_2.png" alt="" id="img2"></button>
            </div>
         </div>
         <div class="col-xs-3 open_x" id="profile_tools">
            <div class="col-xs-9">
              <div class="row">
                  <h4>Павел Пронин</h4>
                  <h5>Рентгенолог</h5>
               </div>
            </div>
            <div class="col-xs-3">
               <img src="img/icons/profile_icon.png" alt="">
            </div>
         </div>
        <div class="mover">
            <a href="#"><button type="button" class="mover_button" style="border:none;"><img src="img/icons/profile_ico.svg" alt="" id="profile_ico">Профиль</button></a>
            <br>
            <a href="#"><button type="button" class="mover_button"><img src="img/icons/exit_ico.svg" alt="" id="profile_ico">Выйти</button></a>
        </div>
      </div>
   </header>
   <!--   header stable  -->
